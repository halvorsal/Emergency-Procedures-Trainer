# Emergency Procedures Trainer

Lokal treningsside for emergency procedures.

## Bruk

Åpne `index.html` lokalt, eller publiser mappen med GitHub Pages.

## GitHub Pages-oppsett

1. Lag et nytt repository på GitHub, for eksempel:
   `emergency-procedures-trainer`

2. Last opp disse filene:
   - `index.html`
   - `.nojekyll`
   - `README.md`

3. Gå til:
   `Settings` → `Pages`

4. Under `Build and deployment`:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`

5. Trykk `Save`.

Etter litt får du en link som typisk blir:

`https://BRUKERNAVN.github.io/emergency-procedures-trainer/`

## Personvern / progresjon

Svar, score, innstillinger og redigert fasit lagres med `localStorage` i nettleseren.

Det betyr:
- Din progresjon lagres bare hos deg.
- Andre som åpner samme link starter med sin egen lokale progresjon.
- Ingen server/database brukes.
- Ingen innlogging trengs.

## Backup

Bruk `Eksporter fasit/svar` inne i programmet for å ta backup av din egen lokale progresjon.
